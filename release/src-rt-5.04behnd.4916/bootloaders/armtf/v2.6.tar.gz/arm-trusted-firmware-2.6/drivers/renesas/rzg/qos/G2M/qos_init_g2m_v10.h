/*
 * Copyright (c) 2020, Renesas Electronics Corporation. All rights reserved.
 *
 * SPDX-License-Identifier: BSD-3-Clause
 */

#ifndef QOS_INIT_G2M_V10_H
#define QOS_INIT_G2M_V10_H

void qos_init_g2m_v10(void);

#endif /* QOS_INIT_G2M_V10_H */
