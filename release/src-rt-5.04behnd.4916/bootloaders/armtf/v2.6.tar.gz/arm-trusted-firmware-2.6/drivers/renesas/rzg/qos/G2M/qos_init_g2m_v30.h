/*
 * Copyright (c) 2020, Renesas Electronics Corporation. All rights reserved.
 *
 * SPDX-License-Identifier: BSD-3-Clause
 */

#ifndef QOS_INIT_G2M_V30_H
#define QOS_INIT_G2M_V30_H

void qos_init_g2m_v30(void);

#endif	/* QOS_INIT_G2M_V30_H */
