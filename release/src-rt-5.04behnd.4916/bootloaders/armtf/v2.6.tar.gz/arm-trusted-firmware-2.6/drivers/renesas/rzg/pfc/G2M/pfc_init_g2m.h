/*
 * Copyright (c) 2020, Renesas Electronics Corporation. All rights reserved.
 *
 * SPDX-License-Identifier: BSD-3-Clause
 */

#ifndef PFC_INIT_G2M_H
#define PFC_INIT_G2M_H

void pfc_init_g2m(void);

#endif /* PFC_INIT_G2M_H */
